# **Social-Media-web-Application**
A Social Media Web Application Implemented on Flask on which user can share their recipes and connect with the rest the world
