from flask import Flask,render_template, request, session, redirect
from werkzeug.utils import secure_filename
from flask_mysqldb import MySQL
import os
import string
import random
import datetime
from routes import *
 
app = Flask(__name__)
app.secret_key=os.urandom(24)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'takoloka'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'hungerger'
mysql = MySQL(app)

app.config['UPLOAD_FOLDER'] = './static/uploads/'


recipes_hdl = Blueprint('recipes_hdl', __name__, template_folder='routes')
user_hdl = Blueprint('user_hdl', __name__, template_folder='routes')
 
# Template for users
@user_hdl.route("/user")
def home():
    return render_template('/login')

# Template for recipes
@recipes_hdl.route("/recipes")
def home():
    return render_template('/')

@app.route('/test')
def test():
    return render_template('test.html')

def get_path():
    path = request.root_url.replace('/?','')
    return path

app.run(port=5000, debug=True)