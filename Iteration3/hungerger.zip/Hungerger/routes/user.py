from flask import Flask,render_template, request, session, redirect
from werkzeug.utils import secure_filename
from flask_mysqldb import MySQL
import os
import string
import random
import datetime



#Gets the user via user_id
def get_user(of_user = '', all=False):
    cursor = mysql.connection.cursor()
    if of_user != '':
        cursor.execute("""select first_name, last_name, username, user_id, avatar from reg_user where user_id = '{}'""".format(of_user))
    elif all:
        cursor.execute("""select first_name, last_name, username, user_id, avatar, email from reg_user where user_id = '{}'""".format(session['user_id']))
    else:
        cursor.execute("""select first_name, last_name, username, user_id, avatar from reg_user where user_id = '{}'""".format(session['user_id']))
    user = cursor.fetchall()
    return user

# Login User GET
@app.route('/login')
def login():
    if 'user_id' in session:
        return redirect('/')
    else:
        print(request.root_url)
        return render_template('login.html')

# Register User GET
@app.route('/register')
def register():
    if 'user_id' in session:
        return redirect('/')
    else:
        return render_template('register.html')

# Login User POST & Validation
@app.route('/login_validation', methods=['POST'])
def login_validation():
    name = request.form.get('name')
    password = request.form.get('password')
    cursor = mysql.connection.cursor()
    cursor.execute("""SELECT * FROM `reg_user` WHERE `username` LIKE '{}' AND `password` LIKE '{}'""".format(name, password))
    reg_user = cursor.fetchall()
    if len(reg_user)>0:
        session['user_id'] = reg_user[0][0]
        return redirect('/')
    else:
        return redirect('/login')
    
# Register User POST
@app.route('/add_user', methods=['POST'])
def add_user():
    name=request.form.get('name')
    email=request.form.get('email')
    password=request.form.get('password')
    cursor = mysql.connection.cursor()
    cursor.execute("""INSERT INTO `reg_user` (`first_name`, `last_name`, `username`, `email`, `password`) values ("{}","{}","{}","{}","{}")""".format(name,email,password))
    print("""INSERT INTO `reg_user` (`first_name`, `last_name`, `username`, `email`, `password`) values ("{}","{}","{}","{}","{}")""".format(name,email,password))
    mysql.connection.commit()
    return redirect('/login')

# Update User POST
@app.route('/update-profile', methods=['POST'])
def update_profile():
    if 'user_id' in session:
        username=request.form.get('username')
        email=request.form.get('email')
        user_id = session['user_id']
        cursor = mysql.connection.cursor()
        # print("""INSERT INTO `recipes` (`raw_post`, `user_id`, `posted_at`) values ("{}","{}","{}")""".format(post_data, user_id, created_at))
        cursor.execute("""UPDATE `reg_user` SET username = '{}', email = '{}' where user_id = '{}' """.format(username, email, user_id))
        mysql.connection.commit()
        return redirect('/')
    else:
        return redirect('/login')
    
# Get User GET
@app.route('/@<path:user_id>')
def user(user_id):
    if 'user_id' in session:
        path = get_path()
        res = get_user(user_id)
        user = get_user()
        print(res)
        if len(res) > 0:
            recipes = get_recipes(res[0][1])
            return render_template('profile.html', res = res, user = user, recipes = recipes, path=path)
        else:
            return f'No User Found'
    else:
        return redirect('/login')
    
# Update User POST Specific
@app.route('/@<path:user_id>/edit-profile')
def edit_profile(user_id):
    if 'user_id' in session:
        if session['user_id'] == user_id:
            path = get_path()
            user = get_user(all=True)
            return render_template('edit-profile.html', user = user, path=path)
        else:
            red = '/@'+user_id
            return redirect(red)
    else:
        return redirect('/login')

# Logout User
@app.route('/logout')
def logout():
    if 'user_id' in session:
        session.pop('user_id')
    return redirect('/login')